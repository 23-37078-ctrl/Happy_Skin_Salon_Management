from sqlalchemy import Column, DateTime, ForeignKey, Integer, String, Text, func
from sqlalchemy.orm import relationship

from app.core.database import Base


class Feedback(Base):
    __tablename__ = "feedback"

    id = Column(Integer, primary_key=True, index=True)
    booking_id = Column(Integer, ForeignKey("bookings.id"), nullable=False)
    customer_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    rating = Column(Integer, nullable=False)
    review = Column(Text, nullable=True)
    service_provider_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    staff_rating = Column(Integer, nullable=True)
    staff_review = Column(Text, nullable=True)
    branch_rating = Column(Integer, nullable=True)
    branch_review = Column(Text, nullable=True)

    created_at = Column(DateTime, server_default=func.now(), nullable=False)

    booking = relationship("Booking")
    customer = relationship("User", foreign_keys=[customer_id])
    service_provider = relationship("User", foreign_keys=[service_provider_id])
