from sqlalchemy import Column, DateTime, ForeignKey, Integer, String, func
from sqlalchemy.orm import relationship
from app.core.database import Base


class Booking(Base):
    __tablename__ = "bookings"

    id               = Column(Integer, primary_key=True, index=True)
    customer_id      = Column(Integer, ForeignKey("users.id"), nullable=True)
    guest_name       = Column(String(100), nullable=True)
    guest_email      = Column(String(255), nullable=True)
    guest_phone      = Column(String(20), nullable=True)
    branch_id        = Column(Integer, ForeignKey("branches.id"), nullable=False)
    service_id       = Column(Integer, ForeignKey("services.id"), nullable=False)
    service_provider_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    preferred_service_provider_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)

    appointment_date = Column(DateTime(timezone=True), nullable=False)
    checked_in_at = Column(DateTime(timezone=True), nullable=True)
    status           = Column(String(20), default="pending", nullable=False)
    # status values: pending | confirmed | completed | cancelled

    notes            = Column(String(255), nullable=True)

    created_at       = Column(DateTime, server_default=func.now(), nullable=False)
    updated_at       = Column(DateTime, server_default=func.now(), onupdate=func.now())

    customer         = relationship("User", foreign_keys=[customer_id])
    branch           = relationship("Branch")
    service          = relationship("Service")
    service_provider = relationship("User", foreign_keys=[service_provider_id])
    preferred_service_provider = relationship("User", foreign_keys=[preferred_service_provider_id])
    service_items = relationship("BookingServiceItem", back_populates="booking", cascade="all, delete-orphan", order_by="BookingServiceItem.id")


class BookingServiceItem(Base):
    __tablename__ = "booking_service_items"
    id = Column(Integer, primary_key=True)
    booking_id = Column(Integer, ForeignKey("bookings.id", ondelete="CASCADE"), nullable=False, index=True)
    service_id = Column(Integer, ForeignKey("services.id"), nullable=False)
    service_provider_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    booking = relationship("Booking", back_populates="service_items")
    service = relationship("Service")
    service_provider = relationship("User", foreign_keys=[service_provider_id])
