from datetime import date, datetime, time, timedelta, timezone
from zoneinfo import ZoneInfo

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, EmailStr, field_validator
from sqlalchemy import func
from sqlalchemy.orm import Session, joinedload

from app.core.database import get_db
from app.core.security import hash_password
from app.dependencies.permissions import require_role
from app.models.booking import Booking
from app.models.branch import Branch
from app.models.feedback import Feedback
from app.models.service import Service
from app.models.transaction import Transaction
from app.models.day_closure import DayClosure
from app.models.promotion import Promotion
from app.models.user import User
from app.services.forecast_service import build_branch_forecast
from app.services.sms_service import normalize_phone_number

router = APIRouter(prefix="/owner", tags=["Owner"])
BUSINESS_TIMEZONE = ZoneInfo("Asia/Manila")
BUSINESS_OPEN_TIME = time(8, 30)
AUTOMATIC_CUTOFF_TIME = time(5, 0)


def _owner_business_date() -> date:
    local_now = datetime.now(BUSINESS_TIMEZONE)
    return local_now.date() if local_now.time() >= BUSINESS_OPEN_TIME else local_now.date() - timedelta(days=1)


def _owner_business_day_bounds(business_date: date) -> tuple[datetime, datetime]:
    local_start = datetime.combine(business_date, BUSINESS_OPEN_TIME, BUSINESS_TIMEZONE)
    local_end = datetime.combine(business_date + timedelta(days=1), AUTOMATIC_CUTOFF_TIME, BUSINESS_TIMEZONE)
    return local_start.astimezone(timezone.utc).replace(tzinfo=None), local_end.astimezone(timezone.utc).replace(tzinfo=None)


class BranchPayload(BaseModel):
    name: str
    address: str
    phone: str | None = None
    is_active: bool = True

    @field_validator("name", "address")
    @classmethod
    def required_text(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("This field is required.")
        return value.strip()


class UserCreatePayload(BaseModel):
    full_name: str
    email: EmailStr
    password: str
    role: str
    branch_id: int | None = None
    phone_number: str | None = None

    @field_validator("full_name")
    @classmethod
    def name_required(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("Full name is required.")
        return value.strip()

    @field_validator("password")
    @classmethod
    def password_length(cls, value: str) -> str:
        if len(value) < 8:
            raise ValueError("Password must be at least 8 characters.")
        return value

    @field_validator("role")
    @classmethod
    def valid_role(cls, value: str) -> str:
        allowed = {"owner", "manager", "staff", "customer"}
        if value not in allowed:
            raise ValueError(f"Role must be one of: {', '.join(sorted(allowed))}")
        return value


class UserUpdatePayload(BaseModel):
    full_name: str
    role: str
    branch_id: int | None = None
    phone_number: str | None = None

    @field_validator("full_name")
    @classmethod
    def update_name_required(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("Full name is required.")
        return value.strip()

    @field_validator("role")
    @classmethod
    def update_valid_role(cls, value: str) -> str:
        return UserCreatePayload.valid_role(value)


def _period_bounds(period: str, start_date: date | None, end_date: date | None) -> tuple[datetime, datetime]:
    if start_date and end_date:
        if end_date < start_date:
            raise HTTPException(status_code=400, detail="End date must be after start date.")
        local_start = datetime.combine(start_date, time.min, BUSINESS_TIMEZONE)
        local_end = datetime.combine(end_date + timedelta(days=1), time.min, BUSINESS_TIMEZONE)
        return local_start.astimezone(timezone.utc).replace(tzinfo=None), local_end.astimezone(timezone.utc).replace(tzinfo=None)

    today = datetime.now(BUSINESS_TIMEZONE).date()
    if period == "daily":
        start = today
    elif period == "weekly":
        start = today - timedelta(days=6)
    elif period == "monthly":
        start = today.replace(day=1)
    elif period == "yearly":
        start = today.replace(month=1, day=1)
    else:
        raise HTTPException(status_code=400, detail="Period must be daily, weekly, monthly, or yearly.")
    local_start = datetime.combine(start, time.min, BUSINESS_TIMEZONE)
    local_end = datetime.combine(today + timedelta(days=1), time.min, BUSINESS_TIMEZONE)
    return local_start.astimezone(timezone.utc).replace(tzinfo=None), local_end.astimezone(timezone.utc).replace(tzinfo=None)


def _serialize_branch(branch: Branch) -> dict:
    return {
        "id": branch.id,
        "name": branch.name,
        "address": branch.address,
        "phone": branch.phone,
        "is_active": branch.is_active,
        "created_at": branch.created_at,
        "updated_at": branch.updated_at,
    }


def _serialize_user(user: User) -> dict:
    return {
        "id": user.id,
        "full_name": user.full_name,
        "email": user.email,
        "role": user.role,
        "branch_id": user.branch_id,
        "phone_number": user.phone_number,
        "email_verified": user.email_verified,
        "created_at": user.created_at,
    }


def _serialize_booking(booking: Booking) -> dict:
    return {
        "id": booking.id,
        "customer": {
            "id": booking.customer.id if booking.customer else None,
            "full_name": booking.customer.full_name if booking.customer else booking.guest_name or "Guest customer",
            "email": booking.customer.email if booking.customer else booking.guest_email,
            "phone_number": booking.customer.phone_number if booking.customer else booking.guest_phone,
        },
        "guest_name": booking.guest_name,
        "guest_email": booking.guest_email,
        "guest_phone": booking.guest_phone,
        "branch": {"id": booking.branch.id, "name": booking.branch.name} if booking.branch else None,
        "service": {
            "id": booking.service.id,
            "name": booking.service.name,
            "price": booking.service.price,
            "duration_minutes": booking.service.duration_minutes,
        } if booking.service else None,
        "service_provider": {
            "id": booking.service_provider.id,
            "full_name": booking.service_provider.full_name,
            "job_title": booking.service_provider.job_title,
        } if booking.service_provider else None,
        "preferred_service_provider": {
            "id": booking.preferred_service_provider.id,
            "full_name": booking.preferred_service_provider.full_name,
            "job_title": booking.preferred_service_provider.job_title,
        } if booking.preferred_service_provider else None,
        "appointment_date": booking.appointment_date,
        "status": booking.status,
        "notes": booking.notes,
        "created_at": booking.created_at,
        "updated_at": booking.updated_at,
    }


def _serialize_transaction(transaction: Transaction) -> dict:
    booking = transaction.booking
    return {
        "id": transaction.id,
        "amount": transaction.amount,
        "payment_method": transaction.payment_method,
        "additional_charge": transaction.additional_charge,
        "charge_reason": transaction.charge_reason,
        "commission_rate": transaction.commission_rate,
        "commission_amount": transaction.commission_amount,
        "created_at": transaction.created_at,
        "staff": {
            "id": transaction.staff.id,
            "full_name": transaction.staff.full_name,
        } if transaction.staff else None,
        "service_provider": {
            "id": transaction.service_provider.id,
            "full_name": transaction.service_provider.full_name,
            "job_title": transaction.service_provider.job_title,
        } if transaction.service_provider else None,
        "booking": {
            "id": booking.id,
            "appointment_date": booking.appointment_date,
            "status": booking.status,
            "branch": {"id": booking.branch.id, "name": booking.branch.name} if booking and booking.branch else None,
            "service": {"id": booking.service.id, "name": booking.service.name} if booking and booking.service else None,
            "customer": {"id": booking.customer.id if booking.customer else None, "full_name": booking.customer.full_name if booking.customer else booking.guest_name or "Guest customer", "phone_number": booking.customer.phone_number if booking.customer else booking.guest_phone} if booking else None,
        } if booking else None,
    }


def _booking_query(db: Session):
    return db.query(Booking).options(
        joinedload(Booking.customer),
        joinedload(Booking.branch),
        joinedload(Booking.service),
        joinedload(Booking.service_provider),
        joinedload(Booking.preferred_service_provider),
    )


def _transaction_query(db: Session):
    return db.query(Transaction).options(
        joinedload(Transaction.staff),
        joinedload(Transaction.service_provider),
        joinedload(Transaction.booking).joinedload(Booking.branch),
        joinedload(Transaction.booking).joinedload(Booking.service),
        joinedload(Transaction.booking).joinedload(Booking.customer),
    )


@router.get("/dashboard")
def get_owner_dashboard(
    current_user: User = Depends(require_role("owner")),
    db: Session = Depends(get_db),
):
    today = date.today()
    today_start = datetime.combine(today, time.min)
    tomorrow_start = today_start + timedelta(days=1)

    salon_revenue_expr = Transaction.amount - func.coalesce(Transaction.commission_amount, 0)
    total_sales = db.query(func.coalesce(func.sum(salon_revenue_expr), 0)).scalar() or 0
    total_staff_commission = db.query(func.coalesce(func.sum(Transaction.commission_amount), 0)).scalar() or 0
    total_collected = db.query(func.coalesce(func.sum(Transaction.amount), 0)).scalar() or 0
    today_bookings = db.query(Booking).filter(
        Booking.appointment_date >= today_start,
        Booking.appointment_date < tomorrow_start,
    ).count()

    stats = {
        "branches": db.query(Branch).count(),
        "active_branches": db.query(Branch).filter(Branch.is_active.is_(True)).count(),
        "users": db.query(User).count(),
        "bookings": db.query(Booking).count(),
        "pending_bookings": db.query(Booking).filter(Booking.status == "pending").count(),
        "today_bookings": today_bookings,
        "transactions": db.query(Transaction).count(),
        "total_sales": float(total_sales),
        "staff_commission": float(total_staff_commission),
        "total_collected": float(total_collected),
    }

    branch_rows = (
        db.query(
            Branch.id,
            Branch.name,
            func.count(Booking.id).label("bookings"),
            func.coalesce(func.sum(salon_revenue_expr), 0).label("sales"),
        )
        .outerjoin(Booking, Booking.branch_id == Branch.id)
        .outerjoin(Transaction, Transaction.booking_id == Booking.id)
        .group_by(Branch.id, Branch.name)
        .order_by(Branch.name.asc())
        .all()
    )
    branch_rankings = []
    for row in branch_rows:
        completed = db.query(Booking).filter(Booking.branch_id == row.id, Booking.status == "completed").count()
        total = int(row.bookings or 0)
        branch_rankings.append({
            "branch_id": row.id,
            "branch": row.name,
            "bookings": total,
            "completed": completed,
            "sales": float(row.sales or 0),
            "completion_rate": round(completed / total * 100, 1) if total else 0,
        })
    branch_rankings.sort(key=lambda item: (item["sales"], item["completed"], item["bookings"]), reverse=True)
    for index, item in enumerate(branch_rankings, start=1):
        item["rank"] = index

    service_rows = (
        db.query(
            Service.name,
            func.count(Booking.id).label("bookings"),
            func.coalesce(func.sum(salon_revenue_expr), 0).label("sales"),
        )
        .outerjoin(Booking, Booking.service_id == Service.id)
        .outerjoin(Transaction, Transaction.booking_id == Booking.id)
        .group_by(Service.name)
        .order_by(func.count(Booking.id).desc())
        .limit(6)
        .all()
    )

    return {
        "stats": stats,
        "branch_performance": [
            {"branch_id": row.id, "branch": row.name, "bookings": row.bookings, "sales": float(row.sales or 0)}
            for row in branch_rows
        ],
        "branch_rankings": branch_rankings,
        "top_branch": branch_rankings[0] if branch_rankings else None,
        "service_demand": [
            {"service": row.name, "bookings": row.bookings, "sales": float(row.sales or 0)}
            for row in service_rows
        ],
        "recent_bookings": [_serialize_booking(item) for item in _booking_query(db).order_by(Booking.created_at.desc()).limit(6).all()],
        "recent_transactions": [
            _serialize_transaction(item)
            for item in _transaction_query(db).order_by(Transaction.created_at.desc()).limit(6).all()
        ],
    }


@router.get("/branches")
def list_owner_branches(
    current_user: User = Depends(require_role("owner")),
    db: Session = Depends(get_db),
):
    branches = db.query(Branch).order_by(Branch.name.asc()).all()
    return {
        "branches": [
            {
                **_serialize_branch(branch),
                "bookings": db.query(Booking).filter(Booking.branch_id == branch.id).count(),
                "sales": float(
                    db.query(func.coalesce(func.sum(Transaction.amount - func.coalesce(Transaction.commission_amount, 0)), 0))
                    .join(Booking, Transaction.booking_id == Booking.id)
                    .filter(Booking.branch_id == branch.id)
                    .scalar()
                    or 0
                ),
                "assigned_users": db.query(User).filter(User.branch_id == branch.id).count(),
                "campaigns": db.query(Promotion.id).filter(Promotion.branch_id == branch.id).count(),
                "closed_days": db.query(DayClosure.id).filter(DayClosure.branch_id == branch.id).count(),
            }
            for branch in branches
        ]
    }


@router.post("/branches", status_code=201)
def create_owner_branch(
    payload: BranchPayload,
    current_user: User = Depends(require_role("owner")),
    db: Session = Depends(get_db),
):
    branch = Branch(**payload.model_dump())
    db.add(branch)
    db.commit()
    db.refresh(branch)
    return _serialize_branch(branch)


@router.patch("/branches/{branch_id}")
def update_owner_branch(
    branch_id: int,
    payload: BranchPayload,
    current_user: User = Depends(require_role("owner")),
    db: Session = Depends(get_db),
):
    branch = db.query(Branch).filter(Branch.id == branch_id).first()
    if not branch:
        raise HTTPException(status_code=404, detail="Branch not found.")
    for field, value in payload.model_dump().items():
        setattr(branch, field, value)
    branch.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(branch)
    return _serialize_branch(branch)


@router.delete("/branches/{branch_id}")
def remove_owner_branch(
    branch_id: int,
    current_user: User = Depends(require_role("owner")),
    db: Session = Depends(get_db),
):
    branch = db.query(Branch).filter(Branch.id == branch_id).first()
    if not branch:
        raise HTTPException(status_code=404, detail="Branch not found.")

    has_bookings = db.query(Booking.id).filter(Booking.branch_id == branch_id).first() is not None
    has_users = db.query(User.id).filter(User.branch_id == branch_id).first() is not None
    has_campaigns = db.query(Promotion.id).filter(Promotion.branch_id == branch_id).first() is not None
    has_closed_days = db.query(DayClosure.id).filter(DayClosure.branch_id == branch_id).first() is not None
    if has_bookings or has_users or has_campaigns or has_closed_days:
        branch.is_active = False
        branch.updated_at = datetime.utcnow()
        db.commit()
        return {"message": "Branch archived to preserve its booking and staff history.", "archived": True}

    db.delete(branch)
    db.commit()
    return {"message": "Branch removed.", "archived": False}


@router.get("/users")
def list_owner_users(
    role: str | None = None,
    branch_id: int | None = None,
    current_user: User = Depends(require_role("owner")),
    db: Session = Depends(get_db),
):
    query = db.query(User).order_by(User.created_at.desc())
    if role:
        query = query.filter(User.role == role)
    if branch_id:
        query = query.filter(User.branch_id == branch_id)
    branches = {branch.id: branch.name for branch in db.query(Branch).all()}
    return {
        "users": [
            {**_serialize_user(user), "branch_name": branches.get(user.branch_id)}
            for user in query.all()
        ],
        "branches": [{"id": key, "name": value} for key, value in branches.items()],
    }


@router.post("/users", status_code=201)
def create_owner_user(
    payload: UserCreatePayload,
    current_user: User = Depends(require_role("owner")),
    db: Session = Depends(get_db),
):
    if db.query(User).filter(User.email == payload.email).first():
        raise HTTPException(status_code=400, detail="Email is already registered.")
    branch_id = None if payload.role == "customer" else payload.branch_id
    if branch_id and not db.query(Branch).filter(Branch.id == branch_id).first():
        raise HTTPException(status_code=404, detail="Branch not found.")
    user = User(
        full_name=payload.full_name,
        email=str(payload.email).lower(),
        password_hash=hash_password(payload.password),
        role=payload.role,
        branch_id=branch_id,
        phone_number=payload.phone_number,
        email_verified=True,
        otp_method="email",
        verified_at=datetime.utcnow(),
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return _serialize_user(user)


@router.patch("/users/{user_id}")
def update_owner_user(
    user_id: int,
    payload: UserUpdatePayload,
    current_user: User = Depends(require_role("owner")),
    db: Session = Depends(get_db),
):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found.")
    if user.role == "customer" and payload.role != "customer":
        raise HTTPException(status_code=409, detail="A customer account's role cannot be changed after registration.")
    branch_id = None if payload.role == "customer" else payload.branch_id
    if branch_id and not db.query(Branch).filter(Branch.id == branch_id).first():
        raise HTTPException(status_code=404, detail="Branch not found.")
    phone_number = None
    if payload.phone_number and payload.phone_number.strip():
        try:
            phone_number = normalize_phone_number(payload.phone_number)
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc
    phone_changed = phone_number != user.phone_number
    user.full_name = payload.full_name
    user.role = payload.role
    user.branch_id = branch_id
    user.phone_number = phone_number
    if phone_changed:
        user.phone_verified = False
    user.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(user)
    return _serialize_user(user)


@router.get("/bookings")
def list_owner_bookings(
    page: int = 1,
    page_size: int = 50,
    branch_id: int | None = None,
    status_filter: str | None = None,
    current_user: User = Depends(require_role("owner")),
    db: Session = Depends(get_db),
):
    query = _booking_query(db)
    if branch_id:
        query = query.filter(Booking.branch_id == branch_id)
    if status_filter:
        query = query.filter(Booking.status == status_filter)
    total = query.count()
    bookings = query.order_by(Booking.appointment_date.desc()).offset((page - 1) * page_size).limit(page_size).all()
    return {"bookings": [_serialize_booking(item) for item in bookings], "total": total, "page": page, "page_size": page_size}


@router.get("/transactions")
def list_owner_transactions(
    page: int = 1,
    page_size: int = 50,
    branch_id: int | None = None,
    current_user: User = Depends(require_role("owner")),
    db: Session = Depends(get_db),
):
    query = _transaction_query(db)
    if branch_id:
        query = query.join(Booking, Transaction.booking_id == Booking.id).filter(Booking.branch_id == branch_id)
    total = query.count()
    transactions = query.order_by(Transaction.created_at.desc()).offset((page - 1) * page_size).limit(page_size).all()
    return {"transactions": [_serialize_transaction(item) for item in transactions], "total": total, "page": page, "page_size": page_size}


@router.get("/reports")
def get_owner_reports(
    period: str = Query("daily", pattern="^(daily|weekly|monthly|yearly|custom)$"),
    start_date: date | None = None,
    end_date: date | None = None,
    branch_id: int | None = None,
    staff_id: int | None = None,
    service_id: int | None = None,
    booking_type: str | None = Query(None, pattern="^(online|walk_in|guest|registered)$"),
    appointment_status: str | None = Query(None, pattern="^(pending|confirmed|completed|cancelled)$"),
    payment_method: str | None = Query(None, pattern="^(cash|gcash|paypal|card|bank_transfer)$"),
    current_user: User = Depends(require_role("owner")),
    db: Session = Depends(get_db),
):
    start, end = _period_bounds(period, start_date, end_date)
    booking_query = db.query(Booking).filter(Booking.appointment_date >= start, Booking.appointment_date < end)
    transaction_query = db.query(Transaction).join(Booking, Transaction.booking_id == Booking.id).filter(
        Transaction.created_at >= start,
        Transaction.created_at < end,
    )
    if branch_id:
        booking_query = booking_query.filter(Booking.branch_id == branch_id)
        transaction_query = transaction_query.filter(Booking.branch_id == branch_id)
    if staff_id:
        booking_query = booking_query.filter(Booking.service_provider_id == staff_id)
        transaction_query = transaction_query.filter(Transaction.service_provider_id == staff_id)
    if service_id:
        booking_query = booking_query.filter(Booking.service_id == service_id)
        transaction_query = transaction_query.filter(Booking.service_id == service_id)
    if appointment_status:
        booking_query = booking_query.filter(Booking.status == appointment_status)
    if booking_type in {"online", "walk_in"}:
        booking_query = booking_query.filter(Booking.notes.like("Walk-in%") if booking_type == "walk_in" else ~Booking.notes.like("Walk-in%"))
    elif booking_type == "guest":
        booking_query = booking_query.filter(Booking.customer_id.is_(None))
    elif booking_type == "registered":
        booking_query = booking_query.filter(Booking.customer_id.isnot(None))
    if payment_method:
        transaction_query = transaction_query.filter(Transaction.payment_method == payment_method)

    transaction_totals = (
        transaction_query.with_entities(Transaction.booking_id.label("booking_id"), func.sum(Transaction.amount - func.coalesce(Transaction.commission_amount, 0)).label("sales"))
        .group_by(Transaction.booking_id)
        .subquery()
    )
    branch_report_query = (
        db.query(
            Branch.name,
            func.count(func.distinct(Booking.id)).label("bookings"),
            func.coalesce(func.sum(transaction_totals.c.sales), 0).label("sales"),
        )
        .join(Booking, Booking.branch_id == Branch.id)
        .outerjoin(transaction_totals, transaction_totals.c.booking_id == Booking.id)
        .filter(Booking.appointment_date >= start, Booking.appointment_date < end)
        .filter(Booking.service_provider_id == staff_id if staff_id else True)
        .filter(Booking.service_id == service_id if service_id else True)
        .filter(Booking.status == appointment_status if appointment_status else True)
        .filter(Booking.notes.like("Walk-in%") if booking_type == "walk_in" else (~Booking.notes.like("Walk-in%") if booking_type == "online" else True))
        .filter(Booking.customer_id.is_(None) if booking_type == "guest" else (Booking.customer_id.isnot(None) if booking_type == "registered" else True))
        .filter(Booking.branch_id == branch_id if branch_id else True)
    )
    if branch_id:
        branch_report_query = branch_report_query.filter(Branch.id == branch_id)
    branch_rows = (
        branch_report_query
        .group_by(Branch.name)
        .order_by(func.coalesce(func.sum(transaction_totals.c.sales), 0).desc())
        .all()
    )

    service_rows = (
        db.query(Service.name, func.count(func.distinct(Booking.id)).label("bookings"), func.coalesce(func.sum(transaction_totals.c.sales), 0).label("sales"))
        .join(Booking, Booking.service_id == Service.id)
        .outerjoin(transaction_totals, transaction_totals.c.booking_id == Booking.id)
        .filter(Booking.appointment_date >= start, Booking.appointment_date < end)
        .filter(Booking.service_provider_id == staff_id if staff_id else True)
        .filter(Booking.service_id == service_id if service_id else True)
        .filter(Booking.status == appointment_status if appointment_status else True)
        .filter(Booking.notes.like("Walk-in%") if booking_type == "walk_in" else (~Booking.notes.like("Walk-in%") if booking_type == "online" else True))
        .filter(Booking.customer_id.is_(None) if booking_type == "guest" else (Booking.customer_id.isnot(None) if booking_type == "registered" else True))
        .filter(Branch.id == branch_id if branch_id else True)
        .group_by(Service.name)
        .order_by(func.count(func.distinct(Booking.id)).desc())
        .all()
    )

    if branch_id:
        service_rows = (
            db.query(Service.name, func.count(func.distinct(Booking.id)).label("bookings"), func.coalesce(func.sum(transaction_totals.c.sales), 0).label("sales"))
            .join(Booking, Booking.service_id == Service.id)
            .outerjoin(transaction_totals, transaction_totals.c.booking_id == Booking.id)
            .filter(Booking.appointment_date >= start, Booking.appointment_date < end, Booking.branch_id == branch_id)
            .filter(Booking.service_provider_id == staff_id if staff_id else True)
            .filter(Booking.service_id == service_id if service_id else True)
            .filter(Booking.status == appointment_status if appointment_status else True)
            .filter(Booking.notes.like("Walk-in%") if booking_type == "walk_in" else (~Booking.notes.like("Walk-in%") if booking_type == "online" else True))
            .filter(Booking.customer_id.is_(None) if booking_type == "guest" else (Booking.customer_id.isnot(None) if booking_type == "registered" else True))
            .group_by(Service.name)
            .order_by(func.count(func.distinct(Booking.id)).desc())
            .all()
        )

    return {
        "period": period,
        "start_date": start.date().isoformat(),
        "end_date": (end - timedelta(days=1)).date().isoformat(),
        "summary": {
            "bookings": booking_query.count(),
            "completed": booking_query.filter(Booking.status == "completed").count(),
            "pending": booking_query.filter(Booking.status == "pending").count(),
            "cancelled": booking_query.filter(Booking.status == "cancelled").count(),
            "sales": float(transaction_query.with_entities(func.coalesce(func.sum(Transaction.amount - func.coalesce(Transaction.commission_amount, 0)), 0)).scalar() or 0),
            "staff_commission": float(transaction_query.with_entities(func.coalesce(func.sum(Transaction.commission_amount), 0)).scalar() or 0),
            "total_collected": float(transaction_query.with_entities(func.coalesce(func.sum(Transaction.amount), 0)).scalar() or 0),
        },
        "branches": [{"name": row.name, "bookings": row.bookings, "sales": float(row.sales or 0)} for row in branch_rows],
        "services": [{"name": row.name, "bookings": row.bookings, "sales": float(row.sales or 0)} for row in service_rows],
        "filters": {"branch_id": branch_id, "staff_id": staff_id, "service_id": service_id, "booking_type": booking_type, "appointment_status": appointment_status, "payment_method": payment_method},
    }


@router.get("/reports/dates")
def list_owner_report_dates(
    current_user: User = Depends(require_role("owner")),
    db: Session = Depends(get_db),
):
    branch_ids = [row[0] for row in db.query(Branch.id).all()]
    current_business_date = _owner_business_date()
    business_dates = {current_business_date}
    if branch_ids:
        timestamps = (
            db.query(Transaction.created_at)
            .join(Booking, Transaction.booking_id == Booking.id)
            .filter(Booking.branch_id.in_(branch_ids))
            .order_by(Transaction.created_at.desc())
            .limit(10000)
            .all()
        )
        for (created_at,) in timestamps:
            if not created_at:
                continue
            timestamp = created_at.replace(tzinfo=timezone.utc) if created_at.tzinfo is None else created_at
            local_timestamp = timestamp.astimezone(BUSINESS_TIMEZONE)
            business_date = local_timestamp.date() if local_timestamp.time() >= BUSINESS_OPEN_TIME else local_timestamp.date() - timedelta(days=1)
            if business_date <= current_business_date:
                business_dates.add(business_date)
        closures = db.query(DayClosure.business_date).filter(
            DayClosure.branch_id.in_(branch_ids),
            DayClosure.business_date <= current_business_date,
        ).all()
        business_dates.update(day for (day,) in closures if day)
    return {"dates": [day.isoformat() for day in sorted(business_dates, reverse=True)]}


@router.get("/reports/filters")
def get_owner_report_filters(branch_id: int | None = None, current_user: User = Depends(require_role("owner")), db: Session = Depends(get_db)):
    staff_query = db.query(User).filter(User.role == "staff", User.is_active.is_(True))
    if branch_id:
        staff_query = staff_query.filter(User.branch_id == branch_id)
    staff = staff_query.order_by(User.full_name).all()
    services_query = db.query(Service).filter(Service.is_active.is_(True))
    if branch_id:
        services_query = services_query.join(Service.branches).filter(Branch.id == branch_id)
    services = services_query.order_by(Service.name).all()
    branches = db.query(Branch).filter(Branch.is_active.is_(True)).order_by(Branch.name).all()
    return {"branches": [{"id": item.id, "name": item.name} for item in branches], "staff": [{"id": item.id, "name": item.full_name} for item in staff], "services": [{"id": item.id, "name": item.name} for item in services]}


@router.get("/reports/day-summary")
def get_owner_day_report(
    report_date: date,
    current_user: User = Depends(require_role("owner")),
    db: Session = Depends(get_db),
):
    branch_rows = db.query(Branch).order_by(Branch.name).all()
    branch_ids = [branch.id for branch in branch_rows]
    start, end = _owner_business_day_bounds(report_date)
    transactions = []
    if branch_ids:
        transactions = (
            db.query(Transaction)
            .options(
                joinedload(Transaction.booking).joinedload(Booking.service),
                joinedload(Transaction.booking).joinedload(Booking.branch),
            )
            .join(Booking, Transaction.booking_id == Booking.id)
            .filter(Booking.branch_id.in_(branch_ids), Transaction.created_at >= start, Transaction.created_at < end)
            .order_by(Transaction.created_at.asc())
            .all()
        )
    closures = db.query(DayClosure).options(joinedload(DayClosure.closed_by)).filter(
        DayClosure.branch_id.in_(branch_ids),
        DayClosure.business_date == report_date,
    ).all() if branch_ids else []
    automatic_cutoff = datetime.combine(report_date + timedelta(days=1), AUTOMATIC_CUTOFF_TIME, BUSINESS_TIMEZONE)
    automatically_closed = datetime.now(BUSINESS_TIMEZONE) >= automatic_cutoff
    automatic_cutoff_utc = automatic_cutoff.astimezone(timezone.utc).replace(tzinfo=None)
    branch_reports = {
        branch.id: {
            "branch_id": branch.id,
            "branch_name": branch.name,
            "online_count": 0,
            "walk_in_count": 0,
            "total_collected": 0.0,
            "commission_total": 0.0,
            "payment_methods": {method: 0.0 for method in ("cash", "gcash", "card", "bank_transfer", "paypal")},
            "services": {},
        }
        for branch in branch_rows
    }
    for transaction in transactions:
        booking = transaction.booking
        amount = float(transaction.amount or 0)
        commission = float(transaction.commission_amount or 0)
        branch_report = branch_reports[booking.branch_id]
        branch_report["total_collected"] += amount
        branch_report["commission_total"] += commission
        branch_report["payment_methods"][transaction.payment_method] = branch_report["payment_methods"].get(transaction.payment_method, 0.0) + amount
        service_name = booking.service.name if booking.service else "Salon service"
        branch_report["services"][service_name] = branch_report["services"].get(service_name, 0) + 1
        if (booking.notes or "").startswith("Walk-in"):
            branch_report["walk_in_count"] += 1
        else:
            branch_report["online_count"] += 1

    all_branches_closed = bool(branch_ids) and len({closure.branch_id for closure in closures}) == len(branch_ids)
    is_closed = all_branches_closed or automatically_closed
    for branch_report in branch_reports.values():
        branch_report["salon_sales"] = round(branch_report["total_collected"] - branch_report.pop("commission_total"), 2)
        branch_report["total_collected"] = round(branch_report["total_collected"], 2)
        branch_report["payment_methods"] = {key: round(value, 2) for key, value in branch_report["payment_methods"].items()}
        branch_report["services"] = [{"name": name, "count": count} for name, count in sorted(branch_report["services"].items(), key=lambda item: item[1], reverse=True)]
    return {
        "report_date": report_date,
        "branch_name": "All branches",
        "prepared_by": current_user.full_name,
        "generated_at": datetime.now(),
        "is_closed": is_closed,
        "closed_at": max((closure.closed_at for closure in closures), default=automatic_cutoff_utc if automatically_closed else None),
        "closed_by": "All branches" if all_branches_closed else "Automatic 5:00 AM cutoff" if automatically_closed else None,
        "branches": list(branch_reports.values()),
    }


@router.get("/dashboard/performance")
def get_owner_dashboard_performance(
    period: str = Query("weekly", pattern="^(daily|weekly|monthly|yearly)$"),
    current_user: User = Depends(require_role("owner")),
    db: Session = Depends(get_db),
):
    start, end = _period_bounds(period, None, None)
    branches = db.query(Branch).filter(Branch.is_active.is_(True)).order_by(Branch.name).all()
    results = []
    for branch in branches:
        bookings = db.query(Booking).filter(Booking.branch_id == branch.id, Booking.appointment_date >= start, Booking.appointment_date < end)
        booking_count = bookings.count()
        completed = bookings.filter(Booking.status == "completed").count()
        sales = float(db.query(func.coalesce(func.sum(Transaction.amount - func.coalesce(Transaction.commission_amount, 0)), 0)).join(Booking, Transaction.booking_id == Booking.id).filter(Booking.branch_id == branch.id, Transaction.created_at >= start, Transaction.created_at < end).scalar() or 0)
        branch_rating = float(db.query(func.avg(Feedback.branch_rating)).join(Booking, Feedback.booking_id == Booking.id).filter(Booking.branch_id == branch.id, Feedback.branch_rating.isnot(None), Feedback.created_at >= start, Feedback.created_at < end).scalar() or 0)
        transaction_rows = db.query(Transaction.service_provider_id.label("provider_id"), func.count(Transaction.id).label("services"), func.coalesce(func.sum(Transaction.amount - func.coalesce(Transaction.commission_amount, 0)), 0).label("revenue"), func.coalesce(func.sum(Transaction.commission_amount), 0).label("commission")).join(Booking, Transaction.booking_id == Booking.id).filter(Booking.branch_id == branch.id, Transaction.service_provider_id.isnot(None), Transaction.created_at >= start, Transaction.created_at < end).group_by(Transaction.service_provider_id).all()
        transaction_metrics = {row.provider_id: row for row in transaction_rows}
        rating_rows = db.query(Feedback.service_provider_id.label("provider_id"), func.avg(Feedback.staff_rating).label("average"), func.count(Feedback.id).label("count")).join(Booking, Feedback.booking_id == Booking.id).filter(Booking.branch_id == branch.id, Feedback.service_provider_id.isnot(None), Feedback.staff_rating.isnot(None), Feedback.created_at >= start, Feedback.created_at < end).group_by(Feedback.service_provider_id).all()
        rating_metrics = {row.provider_id: row for row in rating_rows}
        staff_rows = db.query(User).filter(User.role == "staff", User.branch_id == branch.id, User.is_active.is_(True), User.job_title.isnot(None)).all()
        staff = []
        for member in staff_rows:
            activity = transaction_metrics.get(member.id)
            rating = rating_metrics.get(member.id)
            staff.append({"staff_id": member.id, "full_name": member.full_name, "job_title": member.job_title or "Salon Specialist", "services_completed": int(activity.services if activity else 0), "revenue": float(activity.revenue if activity else 0), "commission": float(activity.commission if activity else 0), "average_rating": round(float(rating.average or 0), 1) if rating else 0, "rating_count": int(rating.count if rating else 0)})
        staff.sort(key=lambda item: (item["revenue"], item["services_completed"], item["average_rating"]), reverse=True)
        results.append({"branch_id": branch.id, "name": branch.name, "address": branch.address, "bookings": booking_count, "completed": completed, "completion_rate": round(completed / booking_count * 100, 1) if booking_count else 0, "sales": sales, "average_rating": round(branch_rating, 1), "staff": staff})
    results.sort(key=lambda item: (item["sales"], item["completed"]), reverse=True)
    return {"period": period, "start_date": start.date().isoformat(), "end_date": (end - timedelta(days=1)).date().isoformat(), "branches": results}


@router.get("/forecasting")
def get_owner_forecasting(
    current_user: User = Depends(require_role("owner")),
    db: Session = Depends(get_db),
):
    branch_ids = [row[0] for row in db.query(Branch.id).filter(Branch.is_active.is_(True)).order_by(Branch.name).all()]
    forecasts = []
    for branch_id in branch_ids:
        forecast = build_branch_forecast(db, branch_id)
        predictions = forecast["predictions"]
        levels = [point["demand_level"] for point in predictions]
        forecasts.append({
            **forecast,
            "branch": forecast["branch_name"],
            "historical_bookings": forecast["readiness"]["completed_appointments"],
            "forecast_bookings": round(sum(point["predicted_demand"] for point in predictions), 1),
            "demand_level": "high" if "high" in levels else "moderate" if "moderate" in levels else "low",
            "method": forecast["model"],
        })
    return {"forecasts": forecasts}


@router.get("/workforce")
def get_owner_workforce(
    current_user: User = Depends(require_role("owner")),
    db: Session = Depends(get_db),
):
    forecast_data = get_owner_forecasting(current_user=current_user, db=db)["forecasts"]
    recommendations = []
    for item in forecast_data:
        actions = list(dict.fromkeys(point["recommendation"] for point in item["predictions"]))
        recommendations.append({
            **item,
            "recommended_staff": None,
            "recommendation": " ".join(actions),
            "capacity_limitation": "Exact staffing cannot be calculated without schedules, working hours, and staff qualifications.",
        })
    return {"recommendations": recommendations}


@router.get("/audit-logs")
def get_owner_audit_logs(
    current_user: User = Depends(require_role("owner")),
    db: Session = Depends(get_db),
):
    events = []
    for user in db.query(User).order_by(User.created_at.desc()).limit(10).all():
        events.append({"type": "user", "action": f"{user.role.title()} account registered", "actor": user.full_name, "created_at": user.created_at})
    for booking in _booking_query(db).order_by(Booking.updated_at.desc()).limit(10).all():
        events.append({"type": "booking", "action": f"Booking marked {booking.status}", "actor": booking.customer.full_name if booking.customer else booking.guest_name or "Customer", "created_at": booking.updated_at or booking.created_at})
    for transaction in _transaction_query(db).order_by(Transaction.created_at.desc()).limit(10).all():
        events.append({"type": "transaction", "action": f"Payment recorded via {transaction.payment_method}", "actor": transaction.staff.full_name if transaction.staff else "Online payment", "created_at": transaction.created_at})
    events.sort(key=lambda event: event["created_at"] or datetime.min, reverse=True)
    return {"audit_logs": events[:30]}
