﻿import { useCallback, useEffect, useMemo, useState } from "react";
import {
  HiOutlineCheckBadge,
  HiOutlineClock,
  HiOutlineExclamationTriangle,
  HiOutlinePresentationChartLine,
} from "react-icons/hi2";
import ForecastChart from "../../assets/components/forecasting/ForecastChart";
import forecastService from "../../services/forecastService";
import ownerService from "../../services/ownerService";
import { getApiError } from "../staff/staffWorkspaceUtils";
import { EmptyState, Notice, OwnerWorkspace } from "./OwnerWorkspace";

export default function ForcastingPage({ embedded = false }) {
  const [forecasts, setForecasts] = useState([]);
  const [selectedBranchId, setSelectedBranchId] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState("");
  const [isTraining, setIsTraining] = useState(false);

  const loadForecasts = useCallback(async () => {
    setIsLoading(true);
    setError("");
    try {
      const branchPayload = await ownerService.branches();
      const activeBranches = (branchPayload.branches || []).filter((branch) => branch.is_active);
      const results = await Promise.all(activeBranches.map((branch) => forecastService.branchForecast(branch.id)));
      setForecasts(results);
      setSelectedBranchId((current) => results.some((item) => String(item.branch_id) === String(current)) ? current : String(results[0]?.branch_id || ""));
    } catch (err) {
      setError(getApiError(err, "We couldn't load demand forecasting."));
    } finally {
      setIsLoading(false);
    }
  }, []);

  const trainModel = async () => {
    setIsTraining(true);
    setError("");
    try {
      const result = await forecastService.train();
      await loadForecasts();
    } catch (err) {
      setError(getApiError(err, "Model training could not be completed. Check whether enough real completed appointments are available."));
    } finally {
      setIsTraining(false);
    }
  };

  useEffect(() => {
    Promise.resolve().then(loadForecasts);
  }, [loadForecasts]);

  const selectedForecast = useMemo(
    () => forecasts.find((item) => String(item.branch_id) === String(selectedBranchId)) || forecasts[0] || null,
    [forecasts, selectedBranchId],
  );

  const content = (
    <>
      {error && <Notice message={error} onRetry={loadForecasts} />}
      {isLoading ? <ForecastPageSkeleton /> : forecasts.length ? (
        <div className="space-y-5">
          <section className="overflow-hidden rounded-[1.5rem] border border-[#F0DDE7] bg-white shadow-[0_16px_44px_rgba(31,41,55,0.06)]">
            <div className="flex flex-col gap-4 border-b border-[#F3E8EF] bg-gradient-to-r from-white via-[#FFF9FC] to-[#FFF2F8] px-5 py-5 sm:flex-row sm:items-center sm:justify-between lg:px-6">
              <div>
                <h2 className="mt-1 text-xl font-bold text-[#1F2937]">Branch demand outlook</h2>
              </div>
              <div className="flex flex-col gap-3 sm:flex-row sm:items-end"><label className="block w-full text-xs font-bold uppercase tracking-wide text-[#6B7280] sm:min-w-56 sm:w-auto">
                Branch
                <select value={selectedBranchId} onChange={(event) => setSelectedBranchId(event.target.value)} className="mt-2 min-h-11 w-full rounded-xl border border-[#EBCFDE] bg-white px-3 py-2 text-sm font-bold normal-case text-[#1F2937] outline-none transition focus:border-[#D65A9A] focus:ring-2 focus:ring-[#D65A9A]/15">
                  {forecasts.map((forecast) => <option key={forecast.branch_id} value={forecast.branch_id}>{forecast.branch_name}</option>)}
                </select>
              </label><button type="button" onClick={trainModel} disabled={isTraining || isLoading} className="min-h-11 rounded-xl bg-[#C85B95] px-4 py-2 text-sm font-bold text-white transition hover:bg-[#A83F78] disabled:cursor-not-allowed disabled:opacity-60">{isTraining ? "Training model…" : "Train on actual records"}</button></div>
            </div>
            {selectedForecast && <ForecastWorkspace forecast={selectedForecast} />}
          </section>
        </div>
      ) : <EmptyState title="No active branches" description="Create an active branch before generating forecasts." />}
    </>
  );

  if (embedded) return <section aria-labelledby="owner-forecasting-title" className="mt-6">{content}</section>;

  return <OwnerWorkspace title="Demand Forecasting">{content}</OwnerWorkspace>;
}

function ForecastWorkspace({ forecast }) {
  const usesSampleData = forecast.data_source === "synthetic_csv";
  const predictions = forecast.predictions || [];
  const forecastTotal = predictions.reduce((sum, point) => sum + Number(point.predicted_demand || 0), 0);
  const readinessTargets = [
    forecast.readiness.history_days / 56,
    forecast.readiness.completed_appointments / 30,
    forecast.readiness.nonzero_days / 14,
  ];
  const readinessProgress = Math.round(Math.min(1, ...readinessTargets) * 100);
  const generatedAt = new Intl.DateTimeFormat("en-PH", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }).format(new Date(forecast.generated_at));

  return (
    <div className="p-4 sm:p-5 lg:p-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div className="flex items-start gap-3">
          <span className="flex h-11 w-11 flex-none items-center justify-center rounded-2xl bg-[#FFF0F7] text-[#C85B95] ring-1 ring-[#F3D4E4]"><HiOutlinePresentationChartLine className="h-6 w-6" /></span>
          <div>
            <h3 className="text-lg font-bold text-[#1F2937]">{forecast.branch_name}</h3>
            <p className="mt-1 text-sm text-[#6B7280]">Updated {generatedAt}</p>
          </div>
        </div>
      </div>

      {forecast.limitation && (
        <div className="mt-5 flex gap-3 rounded-2xl border border-[#F1D69D] bg-[#FFFBF1] p-4 text-[#8A571B]">
          <HiOutlineExclamationTriangle className="mt-0.5 h-5 w-5 flex-none" />
          <div><p className="text-sm font-bold">Forecast confidence is limited</p><p className="mt-1 text-sm leading-6">{forecast.limitation}</p></div>
        </div>
      )}

      <div className="mt-5 grid gap-5 xl:grid-cols-[minmax(0,1.7fr)_minmax(17rem,0.65fr)]">
        <div className="min-w-0 rounded-2xl border border-[#F3E8EF] bg-[#FFFCFD] p-4 sm:p-5">
          <div className="flex flex-wrap items-end justify-between gap-3">
            <div><p className="text-sm font-bold text-[#1F2937]">Demand outlook</p><p className="mt-1 text-xs text-[#6B7280]">{usesSampleData ? "Based on sample transaction history" : "Based on completed appointments"}</p></div>
            <p className="text-right"><span className="block text-2xl font-bold text-[#1F2937]">{forecastTotal.toFixed(1)}</span><span className="text-xs font-semibold text-[#6B7280]">7-day {usesSampleData ? "sample transactions" : "forecast"}</span></p>
          </div>
          <div className="mt-4"><ForecastChart historical={forecast.historical} predictions={predictions} actualLabel={usesSampleData ? "Completed sample transactions" : "Actual completed appointments"} predictedLabel={usesSampleData ? "Predicted sample transactions" : "Predicted demand"} /></div>
        </div>

        <aside className="rounded-2xl border border-[#F3E8EF] bg-white p-5" aria-label={usesSampleData ? "Sample forecast source" : "Model readiness"}>
          <div className="flex items-center gap-2"><HiOutlineCheckBadge className="h-5 w-5 text-[#C85B95]" /><h4 className="text-sm font-bold text-[#1F2937]">{usesSampleData ? "Forecast source" : "Model readiness"}</h4></div>
          {usesSampleData ? <>
            <div className="mt-5 rounded-xl bg-[#FFF8FB] p-3"><p className="text-xs font-bold uppercase tracking-wide text-[#8B7280]">Training data</p><p className="mt-1 text-sm font-bold text-[#1F2937]">3-year sample transaction CSV</p></div>
            <dl className="mt-5 space-y-3">
              <ReadinessRow label="History coverage" value={`${forecast.readiness.history_days.toLocaleString()} days`} />
              <ReadinessRow label="Sample transactions" value={forecast.readiness.completed_appointments.toLocaleString()} />
              <ReadinessRow label="Active days" value={forecast.readiness.nonzero_days.toLocaleString()} />
              <ReadinessRow label="Forecast period" value={forecast.forecast_period} />
            </dl>
            <p className="mt-5 rounded-xl bg-[#FFF8FB] p-3 text-xs leading-5 text-[#6B7280]">These generated sample transactions support the forecast only. They are not added to live sales or customer records.</p>
          </> : <>
          <div className="mt-5 flex items-end justify-between"><span className="text-3xl font-bold text-[#1F2937]">{readinessProgress}%</span><span className="text-xs font-semibold text-[#6B7280]">minimum threshold</span></div>
          <div className="mt-3 h-2 overflow-hidden rounded-full bg-[#F8EAF1]"><div className="h-full rounded-full bg-gradient-to-r from-[#E98AB8] to-[#C85B95] transition-all" style={{ width: `${readinessProgress}%` }} /></div>
          <dl className="mt-5 space-y-3">
            <ReadinessRow label="History coverage" value={`${forecast.readiness.history_days} / 56 days`} />
            <ReadinessRow label="Completed records" value={`${forecast.readiness.completed_appointments} / 30`} />
            <ReadinessRow label="Active demand days" value={`${forecast.readiness.nonzero_days} / 14`} />
            <ReadinessRow label="Forecast period" value={forecast.forecast_period} />
          </dl>
          <p className="mt-5 rounded-xl bg-[#FFF8FB] p-3 text-xs leading-5 text-[#6B7280]">Predictions support planning decisions. Confirm staffing and appointment capacity manually.</p>
          </>}
        </aside>
      </div>

      <DailyOutlook predictions={predictions} usesSampleData={usesSampleData} />
    </div>
  );
}

function DailyOutlook({ predictions, usesSampleData }) {
  return (
    <div className="mt-5 overflow-hidden rounded-2xl border border-[#F3E8EF]">
      <div className="flex items-center justify-between bg-[#FFF9FC] px-4 py-3 sm:px-5"><div><h4 className="text-sm font-bold text-[#1F2937]">Daily operational outlook</h4><p className="mt-0.5 text-xs text-[#6B7280]">Recommended actions by forecast date</p></div><HiOutlineClock className="h-5 w-5 text-[#C85B95]" /></div>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[44rem] text-left">
          <thead className="border-y border-[#F3E8EF] bg-white text-[11px] font-bold uppercase tracking-[0.12em] text-[#8B7280]"><tr><th className="px-5 py-3">Date</th><th className="px-5 py-3">Expected</th><th className="px-5 py-3">Demand level</th><th className="px-5 py-3">Planning guidance</th></tr></thead>
          <tbody className="divide-y divide-[#F6EDF2]">
            {predictions.map((point) => (
              <tr key={point.date} className="bg-white transition hover:bg-[#FFFAFC]">
                <td className="whitespace-nowrap px-5 py-4"><p className="text-sm font-bold text-[#1F2937]">{formatDay(point.date)}</p><p className="mt-0.5 text-xs text-[#6B7280]">{formatDate(point.date)}</p></td>
                <td className="px-5 py-4"><span className="text-lg font-bold text-[#1F2937]">{point.predicted_demand}</span><span className="ml-1 text-xs text-[#6B7280]">{usesSampleData ? "transactions" : "appointments"}</span></td>
                <td className="px-5 py-4"><DemandBadge level={point.demand_level} /></td>
                <td className="max-w-md px-5 py-4 text-sm leading-6 text-[#6B7280]">{point.recommendation}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function DemandBadge({ level }) {
  const styles = level === "high" ? "bg-[#FEE2E2] text-[#991B1B]" : level === "moderate" ? "bg-[#FEF3C7] text-[#92400E]" : "bg-[#ECFDF3] text-[#166534]";
  return <span className={`inline-flex rounded-full px-2.5 py-1 text-xs font-bold capitalize ${styles}`}>{level}</span>;
}

function ReadinessRow({ label, value }) {
  return <div className="flex items-start justify-between gap-3 border-b border-[#F7EEF3] pb-3 last:border-0 last:pb-0"><dt className="text-xs text-[#6B7280]">{label}</dt><dd className="max-w-36 text-right text-xs font-bold text-[#1F2937]">{value}</dd></div>;
}

function ForecastPageSkeleton() {
  return <div className="space-y-5"><div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">{Array.from({ length: 4 }).map((_, index) => <div key={index} className="h-36 animate-pulse rounded-[1.25rem] border border-[#F3E8EF] bg-white"><div className="m-4 h-10 w-10 rounded-xl bg-[#F8EAF1]" /><div className="mx-4 mt-5 h-4 w-2/5 rounded-full bg-[#F8EAF1]" /></div>)}</div><div className="h-[36rem] animate-pulse rounded-[1.5rem] border border-[#F3E8EF] bg-white" /></div>;
}

function localDate(value) {
  return new Date(`${value}T00:00:00`);
}

function formatDay(value) {
  return new Intl.DateTimeFormat("en-PH", { weekday: "short" }).format(localDate(value));
}

function formatDate(value) {
  return new Intl.DateTimeFormat("en-PH", { month: "short", day: "numeric", year: "numeric" }).format(localDate(value));
}
