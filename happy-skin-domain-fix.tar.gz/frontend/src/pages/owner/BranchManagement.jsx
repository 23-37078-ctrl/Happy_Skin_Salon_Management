import { useCallback, useEffect, useState } from "react";
import { HiOutlinePencilSquare, HiOutlinePlus, HiOutlineArchiveBox, HiOutlineTrash, HiOutlineXMark } from "react-icons/hi2";
import ownerService from "../../services/ownerService";
import { formatCurrency, getApiError } from "../staff/staffWorkspaceUtils";
import { CardSkeleton, EmptyState, Notice, OwnerWorkspace } from "./OwnerWorkspace";

const emptyForm = { name: "", address: "", phone: "", is_active: true };

export default function BranchManagement() {
  const [branches, setBranches] = useState([]);
  const [form, setForm] = useState(emptyForm);
  const [createForm, setCreateForm] = useState(emptyForm);
  const [editingId, setEditingId] = useState(null);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [removingId, setRemovingId] = useState(null);

  const loadBranches = useCallback(async () => {
    setIsLoading(true);
    setError("");
    try {
      const payload = await ownerService.branches();
      setBranches(payload.branches || []);
    } catch (err) {
      setError(getApiError(err, "We couldn't load branches."));
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    Promise.resolve().then(() => loadBranches());
  }, [loadBranches]);

  const submit = async (event) => {
    event.preventDefault();
    setIsSaving(true);
    setError("");
    setSuccess("");
    try {
      const payload = editingId ? form : createForm;
      if (editingId) await ownerService.updateBranch(editingId, payload);
      else await ownerService.createBranch(payload);
      setSuccess(editingId ? "Branch updated." : "Branch created.");
      setEditingId(null);
      setIsCreateOpen(false);
      setForm(emptyForm);
      setCreateForm(emptyForm);
      await loadBranches();
    } catch (err) {
      setError(getApiError(err, "We couldn't save this branch."));
    } finally {
      setIsSaving(false);
    }
  };

  const startEdit = (branch) => {
    setError("");
    setIsCreateOpen(false);
    setEditingId(branch.id);
    setForm({ name: branch.name || "", address: branch.address || "", phone: branch.phone || "", is_active: Boolean(branch.is_active) });
  };

  const closeEdit = () => {
    if (isSaving) return;
    setEditingId(null);
    setIsCreateOpen(false);
    setForm(emptyForm);
  };

  const removeBranch = async (branch) => {
    const hasHistory = branch.bookings || branch.assigned_users || branch.campaigns || branch.closed_days;
    const action = hasHistory ? "archive" : "permanently remove";
    if (!window.confirm(`${action === "archive" ? "Archive" : "Permanently remove"} ${branch.name}? ${action === "archive" ? "Its booking and staff history will be preserved." : "This branch has no linked bookings or users."}`)) return;
    setRemovingId(branch.id); setError(""); setSuccess("");
    try {
      const result = await ownerService.removeBranch(branch.id);
      setSuccess(result.message || "Branch removed.");
      if (editingId === branch.id) { setEditingId(null); setForm(emptyForm); }
      await loadBranches();
    } catch (err) { setError(getApiError(err, "We couldn't remove this branch.")); }
    finally { setRemovingId(null); }
  };

  return (
    <OwnerWorkspace title="Branch Management" eyebrow="Create and maintain salon branches">
      {error && <Notice message={error} onRetry={loadBranches} />}
      {success && <Notice tone="success" message={success} />}

      <div className="flex justify-end">
        <button type="button" onClick={() => { setError(""); setCreateForm(emptyForm); setIsCreateOpen(true); }} className="inline-flex min-h-11 items-center justify-center gap-2 rounded-xl bg-[#C85B95] px-5 py-2 text-sm font-bold text-white"><HiOutlinePlus className="h-5 w-5" />Add branch</button>
      </div>

      {(editingId || isCreateOpen) && <div className="fixed inset-0 z-[260] flex items-center justify-center bg-[#172033]/55 p-3 backdrop-blur-sm sm:p-5" onMouseDown={(event) => event.target === event.currentTarget && closeEdit()}>
        <section role="dialog" aria-modal="true" aria-labelledby="branch-modal-title" className="max-h-[92vh] w-full max-w-2xl overflow-y-auto rounded-[1.5rem] border border-[#F3E8EF] bg-white shadow-2xl">
          <header className="sticky top-0 flex items-center justify-between gap-3 border-b border-[#F3E8EF] bg-white px-5 py-4">
            <div><p className="text-xs font-bold uppercase tracking-wide text-[#C85B95]">Branch settings</p><h2 id="branch-modal-title" className="mt-1 text-xl font-extrabold text-[#1F2937]">{editingId ? "Edit branch" : "Add branch"}</h2></div>
            <button type="button" disabled={isSaving} onClick={closeEdit} aria-label="Close branch form" className="grid h-10 w-10 place-items-center rounded-xl text-[#713B5A] hover:bg-[#FFF0F7] disabled:opacity-50"><HiOutlineXMark className="h-6 w-6" /></button>
          </header>
          <form onSubmit={submit} className="space-y-4 p-5">
            {error && <p role="alert" className="rounded-xl bg-red-50 p-3 text-sm text-red-700">{error}</p>}
            <Field label="Branch name" value={editingId ? form.name : createForm.name} onChange={(value) => (editingId ? setForm : setCreateForm)((prev) => ({ ...prev, name: value }))} required />
            <Field label="Address" value={editingId ? form.address : createForm.address} onChange={(value) => (editingId ? setForm : setCreateForm)((prev) => ({ ...prev, address: value }))} required />
            <Field label="Phone" value={editingId ? form.phone : createForm.phone} onChange={(value) => (editingId ? setForm : setCreateForm)((prev) => ({ ...prev, phone: value }))} />
            <label className="flex min-h-11 items-center gap-2 rounded-xl border border-[#F3E8EF] bg-[#FFF8FB] px-3 py-2 text-sm font-bold text-[#1F2937]"><input type="checkbox" checked={editingId ? form.is_active : createForm.is_active} onChange={(event) => (editingId ? setForm : setCreateForm)((prev) => ({ ...prev, is_active: event.target.checked }))} />Active</label>
            <div className="flex flex-col-reverse gap-2 border-t border-[#F3E8EF] pt-4 sm:flex-row sm:justify-end"><button type="button" disabled={isSaving} onClick={closeEdit} className="min-h-11 rounded-xl border border-[#E8B7D0] px-5 font-bold text-[#713B5A] disabled:opacity-50">Cancel</button><button disabled={isSaving} className="inline-flex min-h-11 items-center justify-center gap-2 rounded-xl bg-[#C85B95] px-5 font-bold text-white disabled:opacity-50">{editingId ? <HiOutlinePencilSquare className="h-5 w-5" /> : <HiOutlinePlus className="h-5 w-5" />}{isSaving ? "Saving…" : editingId ? "Save changes" : "Create branch"}</button></div>
          </form>
        </section>
      </div>}

      <section className="mt-5">
        {isLoading ? <CardSkeleton rows={4} /> : branches.length ? (
          <div className="grid gap-4 lg:grid-cols-2">
            {branches.map((branch) => (
              <article key={branch.id} className="rounded-[1.25rem] border border-[#F3E8EF] bg-white p-4 shadow-[0_12px_34px_rgba(31,41,55,0.055)] sm:p-5">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="text-lg font-bold text-[#1F2937]">{branch.name}</p>
                    <p className="mt-1 text-sm text-[#6B7280]">{branch.address}</p>
                    <p className="mt-1 text-xs font-semibold text-[#9CA3AF]">{branch.phone || "No phone listed"}</p>
                  </div>
                  <span className={`rounded-full px-3 py-1 text-xs font-bold ${branch.is_active ? "bg-[#DCFCE7] text-[#166534]" : "bg-[#FEE2E2] text-[#991B1B]"}`}>{branch.is_active ? "Active" : "Inactive"}</span>
                </div>
                <div className="mt-4 grid grid-cols-2 gap-2 text-sm min-[420px]:grid-cols-3 sm:gap-3">
                  <Metric label="Bookings" value={branch.bookings || 0} />
                  <Metric label="Users" value={branch.assigned_users || 0} />
                  <Metric label="Salon revenue" value={formatCurrency(branch.sales)} />
                </div>
                <button type="button" onClick={() => startEdit(branch)} className="mt-4 inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-xl border border-[#D65A9A]/25 bg-white px-4 py-2 text-sm font-bold text-[#1F2937] hover:bg-[#FFF0F7] sm:w-auto">
                  <HiOutlinePencilSquare className="h-5 w-5 text-[#D65A9A]" />
                  Edit
                </button>
                <button type="button" disabled={removingId === branch.id} onClick={() => removeBranch(branch)} className="mt-4 inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-xl border border-red-200 bg-white px-4 py-2 text-sm font-bold text-red-700 hover:bg-red-50 disabled:opacity-50 sm:ml-2 sm:w-auto">
                  {branch.bookings || branch.assigned_users || branch.campaigns || branch.closed_days ? <HiOutlineArchiveBox className="h-5 w-5" /> : <HiOutlineTrash className="h-5 w-5" />}
                  {removingId === branch.id ? "Removing…" : branch.bookings || branch.assigned_users || branch.campaigns || branch.closed_days ? "Archive branch" : "Remove branch"}
                </button>
              </article>
            ))}
          </div>
        ) : <EmptyState title="No branches yet" description="Create branches so bookings, transactions, and managers can be assigned accurately." />}
      </section>
    </OwnerWorkspace>
  );
}

function Field({ label, value, onChange, required = false }) {
  return (
    <label className="text-sm font-bold text-[#1F2937]">
      {label}
      <input required={required} value={value} onChange={(event) => onChange(event.target.value)} className="mt-2 min-h-11 w-full rounded-xl border border-[#F3E8EF] bg-[#FFF8FB] px-3 py-2 text-sm outline-none focus:border-[#D65A9A] focus:ring-2 focus:ring-[#D65A9A]/20" />
    </label>
  );
}

function Metric({ label, value }) {
  return <div className="rounded-xl bg-[#FFF8FB] p-3"><p className="text-xs font-bold uppercase tracking-wide text-[#9CA3AF]">{label}</p><p className="mt-1 truncate font-bold text-[#1F2937]">{value}</p></div>;
}
