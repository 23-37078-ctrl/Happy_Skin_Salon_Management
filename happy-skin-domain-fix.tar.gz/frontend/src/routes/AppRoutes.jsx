import { lazy, Suspense } from "react";
import { Navigate, Route, Routes } from "react-router-dom";
import { useAuth } from "../hooks/useAuth";
import Spinner from "../components/common/Spinner";

// Public
import HomePage from "../pages/public/HomePage";

// Auth
import LoginPage from "../pages/auth/LoginPage";
import RegisterPage from "../pages/auth/RegisterPage";
import VerifyEmailPage from "../pages/auth/VerifyEmailPage";
import ForgotPasswordPage from "../pages/auth/ForgotPasswordPage";

// Owner
import OwnerDashboard from "../pages/owner/OwnerDashboard";
import UserManagement from "../pages/owner/UserManagement";
import AllTransactions from "../pages/owner/AllTransactions";
const WorkforcePage = lazy(() => import("../pages/owner/WorkforcePage"));
import AuditLogPage from "../pages/owner/AuditLogPage";
import CentralizedReports from "../pages/owner/CentralizedReports";
import OwnerCustomerSupport from "../pages/owner/OwnerCustomerSupport";
import OwnerCustomerManagement from "../pages/owner/OwnerCustomerManagement";
import BranchManagement from "../pages/owner/BranchManagement";

// Manager
import ManagerDashboard from "../pages/manager/ManagerDashboard";
import BranchTransactions from "../pages/manager/BranchTransactions";
import BranchReports from "../pages/manager/BranchReports";
const StaffMonitoring = lazy(() => import("../pages/manager/StaffMonitoring"));
import ManagerCustomerFeedback from "../pages/manager/CustomerFeedback";
import ManagerProfile from "../pages/manager/ManagerProfile";
import ManagerPromotions from "../pages/manager/ManagerPromotions";
import ManagerAuditLogs from "../pages/manager/ManagerAuditLogs";

// Staff
import StaffDashboard from "../pages/staff/StaffDashboard";
import BookingHistory from "../pages/staff/BookingHistory";
import OnlineBookings from "../pages/staff/OnlineBookings";
import SubmitFeedback from "../pages/staff/SubmitFeedback";
import DayEndReport from "../pages/staff/DayEndReport";
import GCashVerification from "../pages/staff/GCashVerification";
import CommissionOverview from "../pages/CommissionOverview";

// Customer
import CustomerDashboard from "../pages/customer/CustomerDashboard";
import CustomerBookAppointment from "../pages/customer/CustomerBookAppointment";
import CustomerBookingHistory from "../pages/customer/CustomerBookingHistory";
import CustomerFeedback from "../pages/customer/CustomerFeedback";
import CustomerProfile from "../pages/customer/CustomerProfile";

const ROLE_ROUTES = {
  owner: "/owner/dashboard",
  manager: "/manager/dashboard",
  staff: "/staff/dashboard",
  customer: "/customer/dashboard",
};

function CenteredSpinner() {
  return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: "#F8E5EE" }}>
      <Spinner size="lg" />
    </div>
  );
}

function GuestRoute({ children }) {
  const { isAuthenticated, currentUser, loading } = useAuth();
  if (loading) return <CenteredSpinner />;
  if (isAuthenticated) {
    const redirect = ROLE_ROUTES[currentUser?.role] || "/";
    return <Navigate to={redirect} replace />;
  }
  return children;
}

function PublicRoute({ children }) {
  const { isAuthenticated, currentUser, loading } = useAuth();
  if (loading) return <CenteredSpinner />;
  if (isAuthenticated) {
    const redirect = ROLE_ROUTES[currentUser?.role] || "/";
    return <Navigate to={redirect} replace />;
  }
  return children;
}

function PrivateRoute({ children, allowedRoles }) {
  const { isAuthenticated, currentUser, loading } = useAuth();
  if (loading) return <CenteredSpinner />;
  if (!isAuthenticated) return <Navigate to="/" replace />;
  if (allowedRoles && !allowedRoles.includes(currentUser?.role)) {
    return <Navigate to="/unauthorized" replace />;
  }
  return children;
}

function CustomerBookingRoute({ children }) {
  const { isAuthenticated, currentUser, loading } = useAuth();
  if (loading) return <CenteredSpinner />;
  if (isAuthenticated && currentUser?.role !== "customer") {
    return <Navigate to={ROLE_ROUTES[currentUser?.role] || "/"} replace />;
  }
  return children;
}

function UnauthorizedPage() {
  return (
    <div
      className="min-h-screen flex flex-col items-center justify-center gap-4"
      style={{ background: "#F8E5EE", fontFamily: "'Poppins', sans-serif" }}
    >
      <h1 className="text-3xl font-bold" style={{ color: "#C85B95" }}>Access Denied</h1>
      <p style={{ color: "#6B3F5D" }}>You don't have permission to view this page.</p>
      <a
        href="/login"
        className="px-6 py-2 rounded-xl text-white text-sm font-medium"
        style={{ background: "#C85B95" }}
      >
        Back to Login
      </a>
    </div>
  );
}

export default function AppRoutes() {
  return (
    <Suspense fallback={<CenteredSpinner />}>
      <Routes>
      {/* Public */}
      <Route path="/" element={<PublicRoute><HomePage /></PublicRoute>} />

      {/* Auth */}
      <Route path="/login"        element={<GuestRoute><LoginPage /></GuestRoute>} />
      <Route path="/register"     element={<GuestRoute><RegisterPage /></GuestRoute>} />
      <Route path="/verify-email" element={<VerifyEmailPage />} />
      <Route path="/forgot-password" element={<GuestRoute><ForgotPasswordPage /></GuestRoute>} />

      {/* Owner */}
      <Route path="/owner/dashboard"  element={<PrivateRoute allowedRoles={["owner"]}><OwnerDashboard /></PrivateRoute>} />
      <Route path="/owner/users" element={<PrivateRoute allowedRoles={["owner"]}><UserManagement /></PrivateRoute>} />
      <Route path="/owner/branches" element={<PrivateRoute allowedRoles={["owner"]}><BranchManagement /></PrivateRoute>} />
      <Route path="/owner/bookings"   element={<PrivateRoute allowedRoles={["owner"]}><Navigate to="/owner/transactions" replace /></PrivateRoute>} />
      <Route path="/owner/transactions" element={<PrivateRoute allowedRoles={["owner"]}><AllTransactions /></PrivateRoute>} />
      <Route path="/owner/commissions" element={<PrivateRoute allowedRoles={["owner"]}><CommissionOverview /></PrivateRoute>} />
      <Route path="/owner/forecasting" element={<PrivateRoute allowedRoles={["owner"]}><Navigate to="/owner/dashboard" replace /></PrivateRoute>} />
      <Route path="/owner/workforce"  element={<PrivateRoute allowedRoles={["owner"]}><WorkforcePage /></PrivateRoute>} />
      <Route path="/manager/capacity-review" element={<PrivateRoute allowedRoles={["manager"]}><WorkforcePage /></PrivateRoute>} />
      <Route path="/owner/audit-logs" element={<PrivateRoute allowedRoles={["owner"]}><AuditLogPage /></PrivateRoute>} />
      <Route path="/owner/reports"    element={<PrivateRoute allowedRoles={["owner"]}><CentralizedReports /></PrivateRoute>} />
      <Route path="/owner/support"    element={<PrivateRoute allowedRoles={["owner"]}><OwnerCustomerSupport /></PrivateRoute>} />
      <Route path="/owner/customers"  element={<PrivateRoute allowedRoles={["owner"]}><OwnerCustomerManagement /></PrivateRoute>} />

      {/* Manager */}
      <Route path="/manager/dashboard"    element={<PrivateRoute allowedRoles={["manager"]}><ManagerDashboard /></PrivateRoute>} />
      <Route path="/manager/bookings"     element={<PrivateRoute allowedRoles={["manager"]}><Navigate to="/manager/transactions" replace /></PrivateRoute>} />
      <Route path="/manager/transactions" element={<PrivateRoute allowedRoles={["manager"]}><BranchTransactions /></PrivateRoute>} />
      <Route path="/manager/commissions" element={<PrivateRoute allowedRoles={["manager"]}><CommissionOverview /></PrivateRoute>} />
      <Route path="/manager/reports" element={<PrivateRoute allowedRoles={["manager"]}><BranchReports /></PrivateRoute>} />
      <Route path="/manager/staff"        element={<PrivateRoute allowedRoles={["manager"]}><StaffMonitoring /></PrivateRoute>} />
      <Route path="/manager/feedback"     element={<PrivateRoute allowedRoles={["manager"]}><ManagerCustomerFeedback /></PrivateRoute>} />
      <Route path="/manager/profile"      element={<PrivateRoute allowedRoles={["manager"]}><ManagerProfile /></PrivateRoute>} />
      <Route path="/manager/promotions"   element={<PrivateRoute allowedRoles={["manager"]}><ManagerPromotions /></PrivateRoute>} />
      <Route path="/manager/audit-logs"   element={<PrivateRoute allowedRoles={["manager"]}><ManagerAuditLogs /></PrivateRoute>} />

      {/* Staff */}
      <Route path="/staff/dashboard" element={<PrivateRoute allowedRoles={["staff"]}><StaffDashboard /></PrivateRoute>} />
      <Route path="/staff/online-bookings" element={<PrivateRoute allowedRoles={["staff"]}><OnlineBookings /></PrivateRoute>} />
      <Route path="/staff/transactions" element={<PrivateRoute allowedRoles={["staff"]}><BookingHistory /></PrivateRoute>} />
      <Route path="/staff/gcash-verification" element={<PrivateRoute allowedRoles={["staff"]}><GCashVerification /></PrivateRoute>} />
      <Route path="/staff/commissions" element={<PrivateRoute allowedRoles={["staff"]}><CommissionOverview /></PrivateRoute>} />
      <Route path="/staff/day-end" element={<PrivateRoute allowedRoles={["staff"]}><DayEndReport /></PrivateRoute>} />
      <Route path="/staff/reports" element={<PrivateRoute allowedRoles={["staff"]}><Navigate to="/staff/day-end" replace /></PrivateRoute>} />
      <Route path="/staff/feedback"  element={<PrivateRoute allowedRoles={["staff"]}><SubmitFeedback /></PrivateRoute>} />
      <Route path="/staff/history"   element={<PrivateRoute allowedRoles={["staff"]}><BookingHistory /></PrivateRoute>} />

      {/* Customer */}
      <Route
        path="/customer/dashboard"
        element={
          <PrivateRoute allowedRoles={["customer"]}>
            <CustomerDashboard />
          </PrivateRoute>
        }
      />

      <Route
        path="/customer/book"
        element={
          <CustomerBookingRoute>
            <CustomerBookAppointment />
          </CustomerBookingRoute>
        }
      />

      <Route
        path="/customer/history"
        element={
          <PrivateRoute allowedRoles={["customer"]}>
            <CustomerBookingHistory />
          </PrivateRoute>
        }
      />

      <Route
        path="/customer/profile"
        element={
          <PrivateRoute allowedRoles={["customer"]}>
            <CustomerProfile />
          </PrivateRoute>
        }
      />


      <Route
        path="/customer/feedback"
        element={
          <PrivateRoute allowedRoles={["customer"]}>
            <CustomerFeedback />
          </PrivateRoute>
        }
      />

      <Route
        path="/bookings/new"
        element={
          <PrivateRoute allowedRoles={["customer"]}>
            <CustomerBookAppointment />
          </PrivateRoute>
        }
      />

      <Route
        path="/history"
        element={
          <PrivateRoute allowedRoles={["customer"]}>
            <CustomerBookingHistory />
          </PrivateRoute>
        }
      />

      <Route
        path="/feedback"
        element={
          <PrivateRoute allowedRoles={["customer"]}>
            <CustomerFeedback />
          </PrivateRoute>
        }
      />

      {/* Utility */}
      <Route path="/unauthorized" element={<UnauthorizedPage />} />
      <Route path="*"             element={<Navigate to="/" replace />} />
      </Routes>
    </Suspense>
  );
}
